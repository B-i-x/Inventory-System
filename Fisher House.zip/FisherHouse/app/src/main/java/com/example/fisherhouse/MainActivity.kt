package com.example.fisherhouse

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.client.android.Intents
import com.google.zxing.integration.android.IntentIntegrator
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions


class MainActivity : AppCompatActivity() {

    private val barcodeLauncher: ActivityResultLauncher<ScanOptions> = registerForActivityResult(
        ScanContract()
    ) { result ->
        if (result.getContents() == null) {
            val originalIntent: Intent = result.getOriginalIntent()
            if (originalIntent.hasExtra(Intents.Scan.MISSING_CAMERA_PERMISSION)) {
                Log.d("MainActivity", "Cancelled scan due to missing camera permission")
                Toast.makeText(
                    this@MainActivity,
                    "Cancelled due to missing camera permission",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Log.d("MainActivity", "Scanned")
            Toast.makeText(this@MainActivity, "Scanned: " + result.getContents(), Toast.LENGTH_LONG)
                .show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView = findViewById<TextView>(R.id.textView)

        ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CAMERA), PackageManager.PERMISSION_GRANTED)
    }

    /** Called when the user taps the Send button */
    fun onClick(view : View) {

        val integrator = IntentIntegrator(this)
        integrator.initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
        val scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent)

        if (scanResult != null) {
            var barcode = scanResult.contents
            var typ = scanResult.formatName

            val textView = findViewById<TextView>(R.id.textView).apply {
                text = barcode
            }
        }

        else {

            val toast = Toast.makeText(
                applicationContext,
                "No scan data received!", Toast.LENGTH_SHORT
            )
            toast.show()
        }

        super.onActivityResult(requestCode, resultCode, intent)
    }
}